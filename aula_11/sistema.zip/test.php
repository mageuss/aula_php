<?php
require_once("funcao.php");
echo "Aqui";
revalidarLogin();
