<?php
require_once("funcao.php");
require_once("header.php");
revalidarLogin();
?>

<body>

    <?php require_once("menu.php") ?>

    <div class="content">
        <h2>Página inicial. Bem vindo!</h2>
        <p>Escolha uma opção no menu a esquerda</p>
    </div>

</body>

</html>