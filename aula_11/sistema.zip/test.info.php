<?php 
phpinfo();
?>