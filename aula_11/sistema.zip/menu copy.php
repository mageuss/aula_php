<div class="sidenav">
        <a href="form_inicial.php">Página Inicial</a>
        <a href="form_aluno.php">Administração de alunos</a>
        <a href="form_acesso.php">Administração de acessos</a>
        <a href="#">Administração de materias</a>
        <a href="#">Administração de matriculas</a>
        <a href="#">Administração de notas</a>
        <a href="#">Relatório de notas</a>
        <a href="proc_sessiondestroy.php">Sair</a>
</div>